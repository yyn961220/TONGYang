﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //按钮被电击以后:事件处理
            //MessageBox.Show("you click me ");
            // Form2 frm2a = new Form2();
            //验证登录信息
            //读取输入框的内容
            string s1 = textBox1.Text;
            string s2 = textBox2.Text;
            // MessageBox.Show(s1+"\n"+s2);
            //判断用户名和密码是否正确
            if (s1 == "abc") {
                MessageBox.Show("欢迎你"+s1+"回来");
                Form2 frm2 = new Form2(this);//显示form2时，并将form1传给form2
                frm2.Show();
                this.Hide();//隐藏form1窗口
            }
               
            else
                MessageBox.Show("警报警报，我要把你抓起来");
           
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
