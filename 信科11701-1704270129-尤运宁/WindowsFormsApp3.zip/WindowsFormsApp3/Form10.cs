﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form10 : Form
    {
        //学生类型
        struct Stu
        {
            public string sno;
            public string sname;
        }

        List<Stu> mydata = new List<Stu>();
        public Form10()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form10_Load(object sender, EventArgs e)
        {
            //初始化
            //1.显示标题栏
            listView1.Columns.Add("学号");
            listView1.Columns.Add("姓名");
            listView1.View = View.Details;
            //2.显示内容
            Stu s1 = new Stu();
            s1.sno = "902";
            s1.sname = "姑苏慕容";
            mydata.Add(s1);

            foreach (Stu k in mydata)
            {
                ListViewItem itm = new ListViewItem();
                itm.Text = k.sno.ToString();
                itm.SubItems.Add(k.sname);
                listView1.Items.Add(itm);


            }

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //添加
            //第一步，不能为空
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("请填写完整信息");
                return;
            }
            //实现添加一条记录
            //-查重
            foreach (ListViewItem i in listView1.Items)
            {
                //取item的第一列
                if (i.Text == textBox1.Text)
                {
                    return;                 //如果重复/返回/不添加
                }
            }


            //-添加
            ListViewItem itm = new ListViewItem();
            itm.Text = textBox1.Text;
            itm.SubItems.Add(textBox2.Text);
            listView1.Items.Add(itm);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //删除选中的行
            //--选中的行
            if (listView1.SelectedItems.Count > 0)
            {
                //删除
                foreach (ListViewItem kkk in listView1.SelectedItems)
                {
                    listView1.Items.Remove(kkk);
                }
            }
        }
    }
}
