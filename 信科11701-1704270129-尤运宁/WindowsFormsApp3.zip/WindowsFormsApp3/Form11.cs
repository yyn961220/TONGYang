﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApp3
{
    public partial class Form11 : Form
    {

        string strConn = "server=localhost;user=root;port=3306;password=Yyn1355701658;database=student";
        public Form11()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //链接数据库
            MySqlConnection cnn = new MySqlConnection(strConn);
            cnn.Open();
            MessageBox.Show("打开成功！");
            cnn.Close();  
          

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //插入一条记录
            //INSERT INTO `user` VALUES('BigTony', '123qwe','titianBoss')
            //链接数据库
            MySqlConnection cnn = new MySqlConnection(strConn);
            cnn.Open();

            //2.sql语句----->Command对象
            string strSql = "INSERT INTO user(name,password,role) VALUES('Tony', '12qwe','老大哥')";
            MySqlCommand cmd = new MySqlCommand(strSql,cnn);

            //3.干它
            if (cmd.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("查询到目标，over");
            }
            else {
                MessageBox.Show("任务失败，over");
            }
            //4
            cnn.Close();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //删除一条记录
            //INSERT INTO `user` VALUES('BigTony', '123qwe','titianBoss')
            //链接数据库
            MySqlConnection cnn = new MySqlConnection(strConn);
            cnn.Open();

            //2.sql语句----->Command对象
            string strSql = "delete from user where name='Tony'";
            MySqlCommand cmd = new MySqlCommand(strSql, cnn);

            //3.干它
            if (cmd.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("消灭目标，over");
            }
            else
            {
                MessageBox.Show("任务失败，over");
            }
            //4
            cnn.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            //链接数据库
            MySqlConnection cnn = new MySqlConnection(strConn);
            cnn.Open();

            //2.sql语句----->Command对象
            string strSql = "update user set role ='ebbeb' where name='BigTony'";
            MySqlCommand cmd = new MySqlCommand(strSql, cnn);

            //3.干它
            if (cmd.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("目标营救成功，over");
            }
            else
            {
                MessageBox.Show("任务失败，over");
            }
            //4
            cnn.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {


            //设置显示控件
            listView1.Clear();
            listView1.Columns.Add("姓名");
            listView1.Columns.Add("密码");
            listView1.Columns.Add("角色");



            //链接数据库
            MySqlConnection cnn = new MySqlConnection(strConn);
            cnn.Open();

            //2.sql语句----->Command对象
            string strSql = "select * from user";
            MySqlCommand cmd = new MySqlCommand(strSql, cnn);
            //3.读
            MySqlDataReader sdr = cmd.ExecuteReader();
            int i = 0;
                while (sdr.Read()) {
                listView1.Items.Add(sdr[0].ToString());//姓名
                listView1.Items[i].SubItems.Add(sdr[1].ToString());//密码
                listView1.Items[i].SubItems.Add(sdr[2].ToString());//角色
                i++;

            }
            //4
            cnn.Close();
        }
    }
}
