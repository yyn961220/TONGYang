﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace WindowsFormsApp3
{
    public partial class Form12 : Form
    {
        string strConn = "server=localhost;user=root;port=3306;password=Yyn1355701658;database=student";
        public Form12()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //退出程序
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //登陆
            //链接数据库
            MySqlConnection cnn = new MySqlConnection(strConn);
            cnn.Open();
            //2.sql语句----->Command对象
            string strSql = "select count(*) from user where name = '"+textBox1.Text+"' and password = '"+textBox2.Text+"' and role = '"+comboBox1.Text+"'";

            MySqlCommand cmd = new MySqlCommand(strSql, cnn);
            long k = (long)cmd.ExecuteScalar();     // k>0：表示有该条记录.
            if (k > 0) {
                MessageBox.Show("login successfully" + "\r\n欢迎" + textBox1.Text+"回来");
                //界面切换
                Form f = new Form13(this);//显示form2时，并将form1传给form2
                f.Show();
                this.Hide();//隐藏form1窗口
            }
              
            else
                MessageBox.Show("false!!!");
            cnn.Close();

        }

        private void Form12_Load(object sender, EventArgs e)
        {

        }
    }
}
