﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form13 : Form
    {
        Form _ff;
        public Form13()
        {
            InitializeComponent();
        }
        public Form13(Form f) {
            InitializeComponent();
            _ff = f;

        }
        private void Form13_Load(object sender, EventArgs e)
        {

        }

        private void Form13_FormClosed(object sender, FormClosedEventArgs e)
        {
            _ff.Show();
        }

        private void 浏览ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //
            Form f = new 浏览();
            f.MdiParent = this;
            f.Show();
        }

        private void 编辑ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //
            Form f = new 编辑();
            f.MdiParent = this;
            f.Show();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
