﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form3 : Form
    {
        char choice;
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //编辑单击事件处理工作
            //计算圆周率
            
            Double r = Convert.ToDouble(textBox1.Text);
            const double PI= 3.1415926;
            double areas = PI *r * r;
            textBox3.Text = areas.ToString();
            //MessageBox.Show("面积"+areas);
            
        }

        private void Form3_DpiChangedAfterParent(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //首先判断一下，输入两个数是否为空

            if (textBox1.Text.Trim() == " " || textBox2.Text.Trim()== "") {

                MessageBox.Show("输入信息不完整");
                return;
            }
            //从界面上读出数据，输出到屏幕上
        double  k1 = double.Parse(textBox1.Text);
        double k2 = double.Parse(textBox2.Text);
            double result;
            result = k1 + k2;
            //界面显示结果
            textBox3.Text = result.ToString();
          //  MessageBox.Show("k1:" + k1 + "\nk2:" + k2 + "\nResult:" + result);
        }

        private string ToString(double result)
        {
            throw new NotImplementedException();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text = null;
            textBox2.Text = null;
            textBox3.Text = null;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            double k1 = double.Parse(textBox1.Text);
            double k2 = double.Parse(textBox2.Text);
            double result;
            result = k1 - k2;
            //界面显示结果
            textBox3.Text = result.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            double k1 = double.Parse(textBox1.Text);
            double k2 = double.Parse(textBox2.Text);
            double result;
            result = k1 * k2;
            //界面显示结果
            textBox3.Text = result.ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            double k1 = double.Parse(textBox1.Text);
            double k2 = double.Parse(textBox2.Text);
            double result;
            result = k1*(1/k2);
            //界面显示结果
            textBox3.Text = result.ToString();
        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
