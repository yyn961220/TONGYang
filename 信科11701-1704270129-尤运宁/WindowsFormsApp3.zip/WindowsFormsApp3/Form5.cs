﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    //static int trmCount = 0;
    
    public partial class Form5 : Form
    {
        Form _ff;//定义内部变量
        static int tmrCount;
        public Form5()
        {
            InitializeComponent();
        }
        public Form5(Form frm1)
        {
            InitializeComponent();
            _ff = frm1;
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //combox控件的事件选项
            // MessageBox.Show(comboBox1.SelectedItem.ToString());
            //取出选项字符串
            string s = comboBox1.SelectedItem.ToString();
            if (s=="北京") {
                pictureBox1.Image = Image.FromFile(@"D:\Download\tim\pic_北京.png");
            }
            if (s == "上海")
            {
                pictureBox1.Image = Image.FromFile(@"D:\Download\tim\pic_上海.png");
            }
            if (s == "广州")
            {
                pictureBox1.Image = Image.FromFile(@"D:\Download\tim\pic_广州.png");
            }

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            //编写代码，改变风格
            comboBox1.DropDownStyle = ComboBoxStyle.DropDown;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            comboBox1.DropDownStyle = ComboBoxStyle.Simple;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //添加栏目
            if (textBox1.Text.Trim() == " ")
            {
                return;
            }
            //避免重复
            if (comboBox1.Items.Contains(textBox1.Text))
            {
                return;
            }
            comboBox1.Items.Add(textBox1.Text);

            //其他情况
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //删除combox中的一个选项
            comboBox1.Items.Remove(comboBox1.SelectedItem);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //保存栏目数据
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //显示一张图片
            pictureBox2.Image = Image.FromFile(@"C:\Users\13557\Desktop\5.jpg");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            pictureBox2.Image = Image.FromFile(@"C:\Users\13557\Desktop\4.jpg");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            pictureBox2.Image = Image.FromFile(@"C:\Users\13557\Desktop\7.jpg");
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            //启动，停止定时器
            if (checkBox1.Checked) {
                timer1.Enabled = true;
            }
            else
                timer1.Enabled = false;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //周期性产生Tick事件    ---切换图片实现自动浏览
            //记录当前显示的图片

            tmrCount = (++tmrCount) % 3;
            switch (tmrCount) {
                case 0:
                    pictureBox1.Image = Image.FromFile(@"C:\Users\13557\Desktop\1.png");
                    break;
                case 1:
                    pictureBox1.Image = Image.FromFile(@"C:\Users\13557\Desktop\1.jpg");
                    break;
           
                case 2:
                    pictureBox1.Image = Image.FromFile(@"C:\Users\13557\Desktop\3.jpg");
                    break;
            }


        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }
    }
}
