﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.IO;
using System.Text;
namespace WindowsFormsApp3
{
    public partial class Form6 : Form
    {
        FileStream fs;
        public Form6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //数组运算
            //1.定义数组
            int[] a= new int[10];
            int[] a1 = new int[] {1,2,3,4,5,6 };
            int[] a2={ 1, 2, 3 };
            textBox1.Text += a[0].ToString() + "\r\n" + a1[0].ToString() + "\r\n" + a2[0].ToString();
            //数组访问
            int add = a1[1] + a1[2];
            textBox1.Text += "\r\n加法:" + add;


            //处理字符串
            string s1, s2, s3;
            s1 = "123";
            s2 = "45678";
            textBox1.Text += "\r\n-------------------\r\n" + "s1字符串:" + s1;
            s3 = s1 + s2;
            textBox1.Text += "\r\n" + "s3字符串拼接:" + s3;
            //处理多个字符串-------string[]
            string[] ss1 = new string[10];
            ss1[0] = "第一个字符串";
            ss1[1] = "第二个字符串";
            textBox1.Text += "\r\n" + "字符串数组:" + ss1[0] + "," + ss1[1];

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //ArrayList类:功能强大的数组类
            //定义一个ArrayList
            ArrayList arrayList = new ArrayList();
            arrayList.Add(1);
            arrayList.Add("A");
            arrayList.Add(0.1);

            //for (int i = 0; i < arrayList.Count; i++) {
             //   textBox1.Text += arrayList[i]+="\r\n";
            //""}

            
            //遍历数组
            foreach (object kk in arrayList)
                textBox1.Text += kk + "\r\n";
            textBox1.Text += "\r\n";
            //插入元素到指定位置
            arrayList.Insert(1,"abc");
            foreach (object kk in arrayList)
                textBox1.Text += kk + "\r\n";
            textBox1.Text += "\r\n";
            //删除元素
            arrayList.RemoveAt(1);
            foreach (object kk in arrayList)
                textBox1.Text += kk + "\r\n";

        }
        
        private void Form6_Load(object sender, EventArgs e)
        {
            //初始化，添加标题
            listView1.Columns.Add("学号");
            listView1.Columns.Add("姓名");
            listView1.Columns.Add("年龄");

            //添加第一条静态数据
            listView1.Items.Add("911");
            listView1.Items[0].SubItems.Add("Tony");
            listView1.Items[0].SubItems.Add("21");
            listView1.Items[0].ImageIndex = 0;//设置图标

            //添加第二条静态数据
            listView1.Items.Add("120");
            listView1.Items[1].SubItems.Add("Tonytwo");
            listView1.Items[1].SubItems.Add("20");
            listView1.Items[1].ImageIndex = 1;

            //添加第三条静态数据
            listView1.Items.Add("119");
            listView1.Items[2].SubItems.Add("cxk");
            listView1.Items[2].SubItems.Add("19");
            listView1.Items[2].ImageIndex = 2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Lisr<T>类:类似于ArrayList.但是对元素作了约束<T>
            List<int> mylist = new List<int>();
            //添加
            mylist.Add(12);
            mylist.Add(22);
            mylist.Add(32);
            mylist.Add(42);
            mylist.Add(72);
            mylist.Add(62);
            mylist.Add(52);
            textBox1.Text = "-------------【List】------------";
            foreach (int kk in mylist)
                textBox1.Text += "\r\n" + kk;


            //尝试一下在mylist中存入其他类型数据,"abc"


            //修改
            textBox1.Text += "\r\n";
            textBox1.Text += "\r\n";
            mylist[2] = -1;
            foreach (int kk in mylist)
                textBox1.Text += kk + "\r\n";

            //删除
            mylist.RemoveAt(3);
            foreach (object kk in mylist)
                textBox1.Text += "\r\n" + kk;




            //统计
            //个数
            int k = mylist.Count;
            //MessageBox.Show("数组个数为"+k);


            //排序sort,reverse    
            mylist.Sort();
           
            textBox1.Text += "\r\n=======【排序】========";
            textBox1.Text += "\r\n";
            foreach (int k1 in mylist)
                textBox1.Text += k1+"\r\n";


            //查询:contains,exist,find,findall
            bool a= mylist.Contains(1);
            //MessageBox.Show("是否含1"+22);


            //统计运算:max,min,average  ,sum
            //var通用变量,类似于object
            var r1 = mylist.Max();
            var r2 = mylist.Min();
            var r3 = mylist.Average();
            var r4 = mylist.Sum();
            textBox1.Text += "\r\n=====【统计运算】====\r\n";
            textBox1.Text += "\r\n"+"max:"+r1;
            textBox1.Text += "\r\n" + "min:" + r2;
            textBox1.Text += "\r\n" + "avg:" + r3;
            textBox1.Text += "\r\n" + "sum:" + r4;
        }
        //定义结构体
        struct Stud
        {
            public int sno;
            public string sname;
        };
        List<Stud> myset = new List<Stud>();

        private void button4_Click(object sender, EventArgs e)
        {
            //同学信息管理
            //建立同学一
            Stud s1 = new Stud();
            s1.sno = 101;
            s1.sname = "yyn";
            myset.Add(s1);
            //MessageBox.Show("同学的信息 \n学号:"+myset[0].sno+"\n姓名:"+myset[0].sname);

            //建立同学二
            Stud s2 = new Stud();
            s2.sno = 102;
            s2.sname = "Tony";
            myset.Add(s2);

            //建立同学三
            Stud s3 = new Stud();
            s3.sno = 103;
            s3.sname = "Tony Fake";
            myset.Add(s3);

            //显示信息
            textBox1.Text = "======【同学同学录】=======";
            int i = 0;
            foreach (Stud kk in myset)
            {
                i++;
                textBox1.Text +="\r\n" +"(" +i+")"+"学号:" + kk.sno + "姓名:" + kk.sname;
            }
                
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 处理选择的事件
            // 1).读取选择的内容
            string str = comboBox1.SelectedItem.ToString();

            // 2).判断str的内容，作出相应的处理
            switch (str)
            {
                case "大图标": listView1.View = View.LargeIcon; break;
                case "小图标": listView1.View = View.SmallIcon; break;
                case "列表": listView1.View = View.List; break;
                case "详细": listView1.View = View.Details; break;
                default: break;
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            //添加数据
            //1.读取数据
            String[] strData = {textBox2.Text, textBox3.Text, textBox4.Text };
            ListViewItem item = new ListViewItem(strData);

            //判断是否为空
            if (textBox2.Text.Trim() == "")
                return;

            //判断是否重复:学号
            foreach (ListViewItem i in listView1.Items) {
                if (i.SubItems[0].Text == textBox2.Text)
                    return;
            }



            //2在ListView1末尾插入该行item
            int k = listView1.Items.Count;
            listView1.Items.Insert(k,item);

            //设置图标
            listView1.Items[k].ImageIndex = 0;

        }

        private void button7_Click(object sender, EventArgs e)
        {
        
            //保存到file中去
            int count = listView1.Items.Count;
            MessageBox.Show("共有"+count+"条数据");
            for (int j = 0; j < count; j++) {
                for (int i = 0; i < 3; i++)
                {
                    //listView1.SelectedItems[0].SubItems[1].Text
                    //listView1.SelectedItems[0].SubItems[2].Text
                    textBox1.Text +=listView1.Items[j].SubItems[i].Text+" ";
                }
                textBox1.Text +=  "\r\n";
            }
            fs = new FileStream("d:/a.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            string ss = textBox1.Text;
            //ss->字节的形式,Stream写到文件
            byte[] data = Encoding.Default.GetBytes(ss);
            fs.Position = 0;//把头部指针，指向文件开头，覆盖原数据
            //fs.Position = fs.Length;          //把头部指针，指向文件的末尾，数据添加    
            fs.Write(data, 0, data.Length);
            fs.Close();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            //fs = new FileStream("d:/a.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            //fs.Seek(0,SeekOrigin.Begin);
            //long len = fs.Length;
            //byte[] data = new byte[len];
            //char[] charData = new char[1000];
            // fs.Read(data, 0, data.Length);

            //字节流转化为字符串
            //string ss = Encoding.Default.GetString(data);
            // listView1.Items= ss;
            //fs.Close();
            string s;
            StreamReader sr = new StreamReader(@"d:/a.txt");
            s = sr.ReadToEnd();
            sr.Close();
            string[] sentence = s.Split('\n');
            foreach (string ss in sentence)
            {
                string[] words = ss.Split(' ');
                
                listView1.Items.Add(new ListViewItem(words));
                //listView1.Items.ImageIndex = 0;
            }
            //添加足够的列，注意要将listview的view 设置为details才能看到细节

        }
    }
}
