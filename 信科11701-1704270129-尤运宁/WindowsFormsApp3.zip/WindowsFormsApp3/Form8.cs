﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
namespace WindowsFormsApp3
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            //退出
            //this.Close();关闭当前窗口
            Application.Exit();//关闭整个应用
        }

        private void 我的信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("设计-Tony\n\r版本-007\n\r指导老师-夏老师");
            //在状态栏显示相关信息
            tSSL3.Text = "你查看我的信息";
        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {

        }

        private void Form8_Load(object sender, EventArgs e)
        {
            //初始化
            //在状态栏显示日期时间
            String setData = DateTime.Now.ToString();
            tSSL1.Text = setData;

            //打开定时器
            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //定时器刷新(1s)状态栏第一项，显示日期
            //在状态栏显示日期时间
            String setData = DateTime.Now.ToString();
            tSSL1.Text = setData;

        }

        private void toolStripStatusLabel1_Click_1(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            //打开
            MessageBox.Show("你操作了-打开文件");

            //在状态栏显示相关信息
            tSSL2.Text = "您打开了文件";
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            //int time = 10;
            //定时刷新进度条1s
            if (progressBar1.Value <= progressBar1.Maximum - 10)
                progressBar1.Value += 10;//递增value
            else
                progressBar1.Value = 0;//从头开始
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //循环计数
            for (int i = 0; i < 3; i++)
            {
                Thread.Sleep(1000);
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            timer3.Enabled = false;
            //循环计数
            for (int i = 0; i < 3; i++)
            {
                Thread.Sleep(1000);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer3.Enabled = true;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //创建线程
            Thread t1 = new Thread(new ThreadStart(A));
            t1.Start();
        }
        void A() {
            MessageBox.Show("线程开始计数");
            //三秒计数
            for (int i = 0; i < 3; i++)
            {
                Thread.Sleep(1000);
            }
            MessageBox.Show("线程结束计数");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Thread t2 = new Thread(new ParameterizedThreadStart(B));
            t2.Start(5);
        }
        void B(object obj) {
            MessageBox.Show("线程开始计数");
            //三秒计数
            for (int i = 0; i < (int)obj; i++)
            {
                Thread.Sleep(1000);
            }
            MessageBox.Show("线程结束计数");
        }
    }
}