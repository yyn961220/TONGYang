﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace WindowsFormsApp3
{
    public partial class Form9 : Form
    {
        FileStream fs;
        public Form9()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //打开文件
            fs = new FileStream("d:/a.txt",FileMode.OpenOrCreate,FileAccess.ReadWrite);
            //关闭打开的按钮，避免重复打开
            button1.Enabled = false;
            //打开关闭按钮
            button2.Enabled = true;
            //打开其他按钮
            button3.Enabled = true;
            button4.Enabled = true;


        }

        private void button2_Click(object sender, EventArgs e)
        {
            //没打开之前也失效
           // button2.Enabled = false;
            //关闭文件
            
            fs.Close();
            //放开打开文件的按钮
            button1.Enabled = true ;
            //禁止关闭按钮
            button2.Enabled = false;
            //打开其他按钮
            button3.Enabled = false;
            button4.Enabled = false;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //读取
            //到d:\a.txt读取文件
            //读到的是字节流，转化为string
            //显示到界面
            long len = fs.Length;
            byte[] data = new byte[len];
            fs.Read(data, 0, data.Length);
            //字节流转化为字符串
            string ss = Encoding.Default.GetString(data);
            textBox1.Text = ss;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            //写入文件
            //string ss = "901,yyn,21"+"\r\n";
            string ss = textBox1.Text;
            //ss->字节的形式,Stream写到文件
            byte[] data = Encoding.Default.GetBytes(ss);
            //fs.Position = 0;//把头部指针，指向文件开头，覆盖原数据
            fs.Position = fs.Length;          //把头部指针，指向文件的末尾，数据添加    

            fs.Write(data,0,data.Length);
        
               
        }
    }
}
