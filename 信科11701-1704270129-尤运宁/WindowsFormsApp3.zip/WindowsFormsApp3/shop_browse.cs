﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace WindowsFormsApp3
{
    public partial class shop_browse : Form
    {
        string strConn = "server=localhost;user=root;port=3306;password=Yyn1355701658;database=shop";
        public shop_browse()
        {
            InitializeComponent();
        }

        private void shop_browse_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection cnn = new MySqlConnection(strConn);
            cnn.Open();
            ////3.sql语句----->Command对象
            string strSql = "select * from goodslist";
            MySqlCommand cmd = new MySqlCommand(strSql, cnn);
            //4读取查询的数据集
            MySqlDataAdapter adap = new MySqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adap.Fill(ds);//查询结果
             cnn.Close();//离开数据库

            //5.显示数据从ds中，放到datagridView
            dataGridView1.DataSource = ds.Tables[0].DefaultView;
            dataGridView1.Columns["Goods_Id"].HeaderText = "编号";
            dataGridView1.Columns["Goods_Name"].HeaderText = "名称";
            dataGridView1.Columns["manufacturer"].HeaderText = "生产厂家";
            dataGridView1.Columns["birthday"].HeaderText = "生产日期";
            dataGridView1.Columns["potency"].HeaderText = "保质期";




        }
    }
}
