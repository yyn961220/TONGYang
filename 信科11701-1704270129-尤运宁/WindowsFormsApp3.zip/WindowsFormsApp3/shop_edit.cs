﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace WindowsFormsApp3
{
    public partial class shop_edit : Form
    {
        string strConn = "server=localhost;user=root;port=3306;password=Yyn1355701658;database=shop";
        public shop_edit()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection cnn = new MySqlConnection(strConn);
            cnn.Open();
            //3.sql语句----->Command对象
            //string strSql = "select * from goodslist";
            string strSql = "";
            string sno = textBox1.Text;
            string sname = textBox2.Text;

            if (sno == "" && sname == "")
            {
                strSql = "select * from goodslist";
            }
            else if (sname == "")
            {
                strSql = "select * from goodslist where Goods_Id='" + sno + "'";
            }
            else if (sno == "")
            {
                strSql = "select * from goodslist where Goods_Name='" + sname + "'";
            }
            else {
                strSql = "select * from goodslist where Goods_Name='" + sname + "'"+ " and Goods_Id='"+sno+"' ";
            }
            MySqlCommand cmd = new MySqlCommand(strSql, cnn);
            //4读取查询的数据集
            MySqlDataAdapter adap = new MySqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adap.Fill(ds);//查询结果
            MessageBox.Show("查询成功");
            cnn.Close();//离开数据库

            //5.显示数据从ds中，放到datagridView
            dataGridView1.DataSource = ds.Tables[0].DefaultView;
            dataGridView1.Columns["Goods_Id"].HeaderText = "编号";
            dataGridView1.Columns["Goods_Name"].HeaderText = "名称";
            dataGridView1.Columns["manufacturer"].HeaderText = "生产厂家";
            dataGridView1.Columns["birthday"].HeaderText = "生产日期";
            dataGridView1.Columns["potency"].HeaderText = "保质期";
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = dataGridView1.CurrentRow.Index;
            textBox1.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
            textBox5.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
            textBox4.Text = dataGridView1.Rows[i].Cells[4].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //添加
            MySqlConnection cnn = new MySqlConnection(strConn);
            cnn.Open();

            //3.sql语句----->Command对象
            if (textBox1.Text == "" && textBox2.Text == "")
            {
                MessageBox.Show("请在编号和名称一栏输入信息");
                return;
            }
            string str = "select count(*) from goodslist where Goods_Id='" + textBox1.Text + "'";
            MySqlCommand cmd1 = new MySqlCommand(str, cnn);
            long k = (long)cmd1.ExecuteScalar();
            if (k == 0)
            {
                string strSql = "insert into goodslist values('{0}','{1}','{2}','{3}','{4}')";
                strSql = string.Format(strSql, textBox1.Text, textBox2.Text, textBox3.Text, textBox5.Text, textBox4.Text);
                MySqlCommand cmd = new MySqlCommand(strSql, cnn);
                cmd.ExecuteNonQuery();//执行sql语句,完成插入
                                      //再次读取插入后的数据表
                cmd.CommandText = "select * from goodslist";

                //4读取查询的数据集
                MySqlDataAdapter adap = new MySqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adap.Fill(ds);//查询结果
                MessageBox.Show("添加成功");
                cnn.Close();//离开数据库

                //5.显示数据从ds中，放到datagridView
                dataGridView1.DataSource = ds.Tables[0].DefaultView;
                dataGridView1.Columns["Goods_Id"].HeaderText = "编号";
                dataGridView1.Columns["Goods_Name"].HeaderText = "名称";
                dataGridView1.Columns["manufacturer"].HeaderText = "生产厂家";
                dataGridView1.Columns["birthday"].HeaderText = "生产日期";
                dataGridView1.Columns["potency"].HeaderText = "保质期";

            }
            else {
                MessageBox.Show("重复的商品编号");
                cnn.Close();
                return;
            }
           
            


           

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            MySqlConnection cnn = new MySqlConnection(strConn);
            cnn.Open();
            //3.sql语句----->Command对象
            //string strSql = "select * from goodslist";
            //string strSql = "";
            string sno = textBox1.Text;
            //string sname = textBox2.Text;
            //string factory = textBox3.Text;
            //string birthdaydate = textBox5.Text;
            //string deathdate = textBox4.Text;
            if (textBox1.Text == ""&& textBox2.Text == ""&& textBox3.Text == ""&& textBox5.Text == ""&& textBox4.Text == "") {
                MessageBox.Show("请选中一行");
                return;
            }
            //string str = "select count(*) from goodslist where Goods_Id='" + textBox1.Text + "' ";
            //MySqlCommand cmd1 = new MySqlCommand(str, cnn);
            //long k = (long)cmd1.ExecuteScalar();
           
                string strSql = "update  goodslist set Goods_Id='"+ textBox1.Text + "' ,Goods_Name='" + textBox2.Text + "',manufacturer='" + textBox3.Text + "',birthday='" + textBox5.Text + "',potency='" + textBox4.Text + "' where Goods_Id='" + sno + "'";
                // strSql = string.Format(strSql, textBox1.Text, textBox2.Text, textBox3.Text, textBox5.Text, textBox4.Text);
                MySqlCommand cmd = new MySqlCommand(strSql, cnn);
                cmd.ExecuteNonQuery();//执行sql语句,完成插入
                                      //再次读取插入后的数据表
                cmd.CommandText = "select * from goodslist";

                //4读取查询的数据集
                MySqlDataAdapter adap = new MySqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adap.Fill(ds);//查询结果
            MessageBox.Show("添加成功");
            cnn.Close();//离开数据库

                //5.显示数据从ds中，放到datagridView
                dataGridView1.DataSource = ds.Tables[0].DefaultView;
                dataGridView1.Columns["Goods_Id"].HeaderText = "编号";
                dataGridView1.Columns["Goods_Name"].HeaderText = "名称";
                dataGridView1.Columns["manufacturer"].HeaderText = "生产厂家";
                dataGridView1.Columns["birthday"].HeaderText = "生产日期";
                dataGridView1.Columns["potency"].HeaderText = "保质期";

           
            
             
          
           

           
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            MySqlConnection cnn = new MySqlConnection(strConn);
            cnn.Open();

            //3.sql语句----->Command对象
            //string strSql = "select * from goodslist";
            string strSql = "";
            string sno = textBox1.Text;
            string sname = textBox2.Text;
            //string sname = textBox2.Text;
            //string factory = textBox3.Text;
            //string birthdaydate = textBox5.Text;
            //string deathdate = textBox4.Text;
            if (textBox1.Text == "" && textBox2.Text == "" && textBox3.Text == "" && textBox5.Text == "" && textBox4.Text == "")
            {
                MessageBox.Show("请输入要删除的名称和编号或者选中一行");
                return;
            }else if (sname == "")
            {
                strSql = "delete  from goodslist where Goods_Id='" + sno + "'";
            }
            else if (sno == "")
            {
                strSql = "delete   from goodslist where Goods_Name='" + sname + "'";
            }
            else
            {
                strSql = "delete   from goodslist where Goods_Name='" + sname + "'" + " and Goods_Id='" + sno + "' ";
            }
           // string strSql = "delete from goodslist where Goods_Id='"+sno+"'";
            // strSql = string.Format(strSql, textBox1.Text, textBox2.Text, textBox3.Text, textBox5.Text, textBox4.Text);
            MySqlCommand cmd = new MySqlCommand(strSql, cnn);
            cmd.ExecuteNonQuery();//执行sql语句,完成插入
                                  //再次读取插入后的数据表
            cmd.CommandText = "select * from goodslist";

            //4读取查询的数据集
            MySqlDataAdapter adap = new MySqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adap.Fill(ds);//查询结果
            MessageBox.Show("删除成功");
            cnn.Close();//离开数据库

            //5.显示数据从ds中，放到datagridView
            dataGridView1.DataSource = ds.Tables[0].DefaultView;
            dataGridView1.Columns["Goods_Id"].HeaderText = "编号";
            dataGridView1.Columns["Goods_Name"].HeaderText = "名称";
            dataGridView1.Columns["manufacturer"].HeaderText = "生产厂家";
            dataGridView1.Columns["birthday"].HeaderText = "生产日期";
            dataGridView1.Columns["potency"].HeaderText = "保质期";

        }
    }
}
