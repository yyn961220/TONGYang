﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace WindowsFormsApp3
{
    public partial class shop登陆 : Form
    {
        //链接用得字符串
       // string strConn = "server=localhost;user=root;port=3306;password=Yyn1355701658;database=shop";
        string strConn = "server=localhost;user=root;port=3306;password=Yyn1355701658;database=shop";
        public shop登陆()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //退出程序
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //1.创建数据库链接
        
            MySqlConnection cnn = new MySqlConnection(strConn);
            cnn.Open();
            ////2.sql语句----->Command对象
            string strSql = "select count(*) from user where username = '" + textBox1.Text + "' and password = '" + textBox2.Text + "' and identity = '" + comboBox1.Text + "'";

            MySqlCommand cmd = new MySqlCommand(strSql, cnn);
            long k = (long)cmd.ExecuteScalar();     // k>0：表示有该条记录.
            if (k > 0)
            {
               MessageBox.Show("login successfully" + "\r\n欢迎" + textBox1.Text + "回来");
                //界面切换
                Form f = new 菜单(this);//显示form2时，并将form1传给form2
                f.Show();
                this.Hide();//隐藏form1窗口
            }

            else
                MessageBox.Show("false!!!");
            cnn.Close();
        }

        private void shop登陆_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //添加
            MySqlConnection cnn = new MySqlConnection(strConn);
            cnn.Open();

            //3.sql语句----->Command对象
            if (textBox1.Text == "" && textBox2.Text == ""&&comboBox1.Text=="")
            {
                MessageBox.Show("请输入用户名密码身份");
                return;
            }
            string str = "select count(*) from user where username='" + textBox1.Text + "'";
            MySqlCommand cmd1 = new MySqlCommand(str, cnn);
            long k = (long)cmd1.ExecuteScalar();
            if (k == 0)
            {
                string strSql = "insert into user values('{0}','{1}','{2}')";
                strSql = string.Format(strSql, textBox1.Text, textBox2.Text,comboBox1.Text);
                MySqlCommand cmd = new MySqlCommand(strSql, cnn);
                cmd.ExecuteNonQuery();//执行sql语句,完成插入
                                      //再次读取插入后的数据表
               // cmd.CommandText = "select * from goodslist";

                //4读取查询的数据集
              //  MySqlDataAdapter adap = new MySqlDataAdapter(cmd);
                //DataSet ds = new DataSet();
                //adap.Fill(ds);//查询结果
                MessageBox.Show("注册成功");
                cnn.Close();//离开数据库

                //5.显示数据从ds中，放到datagridView
               

            }
            else
            {
                MessageBox.Show("注册失败");
                cnn.Close();
                return;
            }

        }
    }
}
