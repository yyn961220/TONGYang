﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace WindowsFormsApp3
{
    public partial class 浏览 : Form
    {
        //链接字符串
        string strConn = "server=localhost;user=root;port=3306;password=Yyn1355701658;database=student";
        public 浏览()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //浏览student表
            //登陆
            //链接数据库
            MySqlConnection cnn = new MySqlConnection(strConn);
            cnn.Open();
            //2.sql语句----->Command对象
            string strSql = "select * from stu ";
            MySqlCommand cmd = new MySqlCommand(strSql, cnn);

            //4读取查询的数据集
            MySqlDataAdapter adap = new MySqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adap.Fill(ds);
            cnn.Close();

            //5.从ds中取数据放到界面上去
            dataGridView1.DataSource = ds.Tables[0].DefaultView;
            dataGridView1.Columns["stu_id"].HeaderText = "学号";
                 dataGridView1.Columns["name"].HeaderText = "姓名";
            dataGridView1.Columns["sex"].HeaderText = "性别";
            dataGridView1.Columns["age"].HeaderText = "年龄";
            dataGridView1.Columns["birthday"].HeaderText = "生日";
        }
    }
}
