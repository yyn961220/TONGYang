﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace WindowsFormsApp3
{
    public partial class 编辑 : Form
    {
        string strConn = "server=localhost;user=root;port=3306;password=Yyn1355701658;database=student";
        public 编辑()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //浏览student表
            //登陆
            //链接数据库
            MySqlConnection cnn = new MySqlConnection(strConn);
            cnn.Open();
            //2.sql语句----->Command对象
            // string strSql = "select * from stu ";
            // string strSql = " ";
            string strSql = "";
            string sno = textBox1.Text;
            string sname = textBox2.Text;

            if (sno == "" && sname == "")
                strSql = "select * from stu";           // 没有输入，sno和sname均为空
            else if (sname == "")
                strSql = "select * from stu where stu_id = '" + sno + "'";
            else if (sno == "")
                strSql = "select * from stu where name = '" + sname + "'";
            else
                strSql = "select * from stu where name = '" + sname + "'"
                    + " and stu_id = '" + sno + "'";

            MySqlCommand cmd = new MySqlCommand(strSql, cnn);

            //4读取查询的数据集
            MySqlDataAdapter adap = new MySqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adap.Fill(ds);
            cnn.Close();

            //5.从ds中取数据放到界面上去
            dataGridView1.DataSource = ds.Tables[0].DefaultView;
            dataGridView1.Columns["stu_id"].HeaderText = "学号";
            dataGridView1.Columns["name"].HeaderText = "姓名";
            dataGridView1.Columns["sex"].HeaderText = "性别";
            dataGridView1.Columns["age"].HeaderText = "年龄";
            dataGridView1.Columns["birthday"].HeaderText = "生日";
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            //单击DBG,将选中一行，显示到上方
            int i = dataGridView1.CurrentRow.Index;
            textBox1.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
            textBox4.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
            textBox5.Text = dataGridView1.Rows[i].Cells[4].Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            //链接数据库
            MySqlConnection cnn = new MySqlConnection(strConn);
            cnn.Open();
            //2.sql语句----->Command对象
            // string strSql = "select * from stu ";
            // string strSql = " ";
            string strSql = "insert into stu(stu_id,name,sex,age,birthday) values('{0}','{1}','{2}','{3}','{4}')";
            strSql = string.Format(strSql,textBox1.Text,textBox2.Text, textBox3.Text, textBox4.Text,textBox5.Text);
       

            MySqlCommand cmd = new MySqlCommand(strSql, cnn);
            cmd.ExecuteNonQuery();//执行sql语句
            //再次读取插入后的数据表
            cmd.CommandText = "select * from stu";


            //4读取查询的数据集
            MySqlDataAdapter adap = new MySqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adap.Fill(ds);
            cnn.Close();

            //5.从ds中取数据放到界面上去
            dataGridView1.DataSource = ds.Tables[0].DefaultView;
            dataGridView1.Columns["stu_id"].HeaderText = "学号";
            dataGridView1.Columns["name"].HeaderText = "姓名";
            dataGridView1.Columns["sex"].HeaderText = "性别";
            dataGridView1.Columns["age"].HeaderText = "年龄";
            dataGridView1.Columns["birthday"].HeaderText = "生日";

        }

        private void 编辑_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
