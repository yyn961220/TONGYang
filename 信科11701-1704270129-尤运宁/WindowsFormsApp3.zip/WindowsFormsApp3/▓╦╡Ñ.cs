﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class 菜单 : Form
    {
        Form _ff;
        public 菜单()
        {
            InitializeComponent();
        }
        public 菜单(Form f)
        {
            InitializeComponent();
            _ff = f;

        }
        private void 菜单_Load(object sender, EventArgs e)
        {

        }

        private void 菜单_FormClosed(object sender, FormClosedEventArgs e)
        {
            //退出主界面，恢复登陆界面
            _ff.Show(); 
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //浏览商铺信息
            Form f = new shop_browse();
            f.MdiParent = this;
            f.Show();
        }

        private void 编辑ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //浏览商铺信息
            Form f = new shop_edit();
            f.MdiParent = this;
            f.Show();
        }
    }
}
